package bw.co.fnbbotswana.mailioserver;

public class Main {
    public static void main(String[] args) {
        System.out.println("Mail IO Server");
    }
}